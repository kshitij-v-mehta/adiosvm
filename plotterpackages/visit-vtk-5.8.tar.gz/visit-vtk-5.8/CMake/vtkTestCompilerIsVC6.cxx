/* Compile if this is MSVC 6.  */
#if defined(_MSC_VER) && (_MSC_VER == 1200)
int main()
{
  return 0;
}
#endif
